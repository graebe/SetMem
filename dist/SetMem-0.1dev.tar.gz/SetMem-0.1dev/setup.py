from distutils.core import setup

setup(
    name='SetMem',
    version='0.1dev',
    packages=['SetMem',],
    license='',
    url='https://pypi.org/SetMem',
    long_description=open('README.md').read(),
)